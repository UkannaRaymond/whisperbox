# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: auth-guard.spec.ts >> unauthenticated access to protected routes >> visiting /onboarding/username without a session redirects to /login
- Location: tests\e2e\auth-guard.spec.ts:23:7

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/login$/
Received string:  "http://localhost:3000/onboarding/username"
Timeout: 5000ms

Call log:
  - Expect "toHaveURL" with timeout 5000ms
    13 × locator resolved to <html lang="en" class="figtree_153b756c-module__JuWJOq__variable geist_mono_1bf8cbf6-module__FlyLvG__variable h-full antialiased light">…</html>
       - unexpected value "http://localhost:3000/onboarding/username"

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- link "WhisperBox":
  - /url: /
- img "Loading"
- paragraph: Your messages are end-to-end encrypted
- region "Notifications alt+T"
```